#!/usr/bin/env node

/**
 * Version Sync Script
 *
 * Syncs version from package.json to all files that need version updates:
 * - userscript-header.txt (userscript @version tag)
 * - library-headers/*.txt (all library @version tags)
 * - README.md (badge and footer version)
 * - src/main.js (Toolasha.version property)
 * - src/entrypoint.js (Toolasha.version property)
 *
 * This ensures all version references stay in sync automatically.
 *
 * Usage:
 *   node scripts/sync-version.js
 *   npm run version:sync
 */

import { readFileSync, writeFileSync, readdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

function syncVersion() {
    try {
        // Read version from package.json (source of truth)
        const packageJsonPath = join(rootDir, 'package.json');
        const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
        const version = packageJson.version;

        if (!version) {
            console.error('❌ Error: No version found in package.json');
            process.exit(1);
        }

        let filesUpdated = [];

        // 1. Update userscript-header.txt
        const headerPath = join(rootDir, 'userscript-header.txt');
        let headerContent = readFileSync(headerPath, 'utf8');
        const headerRegex = /^(\/\/ @version\s+)[\d.]+$/m;

        if (!headerRegex.test(headerContent)) {
            console.error('❌ Error: Could not find @version line in userscript-header.txt');
            process.exit(1);
        }

        const updatedHeader = headerContent.replace(headerRegex, `$1${version}`);
        if (updatedHeader !== headerContent) {
            writeFileSync(headerPath, updatedHeader, 'utf8');
            filesUpdated.push('userscript-header.txt');
        }

        // 2. Update all library-headers/*.txt files
        const libraryHeadersDir = join(rootDir, 'library-headers');
        const libraryHeaderFiles = readdirSync(libraryHeadersDir).filter((file) => file.endsWith('.txt'));

        for (const file of libraryHeaderFiles) {
            const filePath = join(libraryHeadersDir, file);
            let fileContent = readFileSync(filePath, 'utf8');

            // Try userscript @version format first (for entrypoint.txt)
            if (headerRegex.test(fileContent)) {
                const updatedContent = fileContent.replace(headerRegex, `$1${version}`);
                if (updatedContent !== fileContent) {
                    writeFileSync(filePath, updatedContent, 'utf8');
                    filesUpdated.push(`library-headers/${file}`);
                }
            }
            // Try JSDoc Version: format (for library headers)
            else {
                const jsdocVersionRegex = /^( \* Version: )[\d.]+$/m;
                if (jsdocVersionRegex.test(fileContent)) {
                    const updatedContent = fileContent.replace(jsdocVersionRegex, `$1${version}`);
                    if (updatedContent !== fileContent) {
                        writeFileSync(filePath, updatedContent, 'utf8');
                        filesUpdated.push(`library-headers/${file}`);
                    }
                } else {
                    console.warn(`⚠️  Warning: Could not find version line in library-headers/${file}`);
                }
            }
        }

        // 3. Update README.md (badge and footer)
        const readmePath = join(rootDir, 'README.md');
        let readmeContent = readFileSync(readmePath, 'utf8');

        // Update badge: ![Version](https://img.shields.io/badge/version-X.X.X-orange?style=flat-square)
        const badgeRegex = /(!\[Version\]\(https:\/\/img\.shields\.io\/badge\/version-)[\d.]+(-.+?\))/;
        // Update footer: **Version**: X.X.X (Pre-release)
        const footerRegex = /(\*\*Version\*\*: )[\d.]+( \(Pre-release\))/;

        let updatedReadme = readmeContent;
        updatedReadme = updatedReadme.replace(badgeRegex, `$1${version}$2`);
        updatedReadme = updatedReadme.replace(footerRegex, `$1${version}$2`);

        if (updatedReadme !== readmeContent) {
            writeFileSync(readmePath, updatedReadme, 'utf8');
            filesUpdated.push('README.md');
        }

        // 4. Update src/main.js and src/entrypoint.js (Toolasha.version property)
        const versionFiles = [
            join(rootDir, 'src', 'main.js'),
            join(rootDir, 'src', 'entrypoint.js'),
        ];

        // Match: version: 'X.X.X', or version = 'X.X.X';
        const versionPropertyRegex = /(version\s*[:=]\s*['"])[\d.]+(['"][,;])/;

        for (const filePath of versionFiles) {
            let fileContent = readFileSync(filePath, 'utf8');

            if (!versionPropertyRegex.test(fileContent)) {
                console.warn(`⚠️  Warning: Could not find version property in ${filePath}`);
                continue;
            }

            const updatedContent = fileContent.replace(versionPropertyRegex, `$1${version}$2`);
            if (updatedContent !== fileContent) {
                writeFileSync(filePath, updatedContent, 'utf8');
                const relativePath = filePath.replace(rootDir + '/', '');
                filesUpdated.push(relativePath);
            }
        }

        // Report results
        if (filesUpdated.length === 0) {
            console.log(`✅ All files already at version ${version}`);
        } else {
            console.log(`✅ Version synced to ${version}`);
            console.log(`   Updated files:`);
            filesUpdated.forEach((file) => console.log(`   - ${file}`));
            console.log(`   (dist files will be updated on next build)`);
        }
    } catch (error) {
        console.error('❌ Error syncing version:', error.message);
        process.exit(1);
    }
}

syncVersion();
